package CS2JNet.System;

public class ObjectSupport {
	public static boolean Equals(Object obj1, Object obj2) {
		if (obj1 == null) {
			return obj2 == null;
		} else {
			return obj1.equals(obj2);
		}
	}
}
