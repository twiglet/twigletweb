3rd Party Software            +  License
==========================================================================================
commons-lang, commons-codec   +  Apache 2.0
                              +
mail                          +  Sun ENTITLEMENT (see http://kenai.com/projects/javamail/pages/License)

  
