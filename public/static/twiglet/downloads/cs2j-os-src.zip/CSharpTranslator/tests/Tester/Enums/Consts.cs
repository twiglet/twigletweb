using System;
namespace Tester
{
	public class Consts
	{
		public Consts ()
		{
		}
		
		public const int Enuma = 2;
		public const int Enumb = 44;
		
	}
}

