using System;
namespace Tester
{
	
	public partial class PartialUser {
		public partial class PartialInner
		{
			private int a = 0;
			
			public PartialInner ()
			{
			}
		}
	}
}

